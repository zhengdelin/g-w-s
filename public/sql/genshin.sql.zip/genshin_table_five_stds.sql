
-- --------------------------------------------------------

--
-- 資料表結構 `five_stds`
--
-- 建立時間： 2021-12-22 11:14:52
-- 最後更新： 2021-12-22 11:14:52
--

DROP TABLE IF EXISTS `five_stds`;
CREATE TABLE IF NOT EXISTS `five_stds` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `five_std_id` int NOT NULL,
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表新增資料前，先清除舊資料 `five_stds`
--

TRUNCATE TABLE `five_stds`;
--
-- 傾印資料表的資料 `five_stds`
--

INSERT INTO `five_stds` (`id`, `five_std_id`, `name`, `kind`, `created_at`, `updated_at`) VALUES
(1, 1, '迪盧克', 'cr', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(2, 1, '莫娜', 'cr', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(3, 1, '琴', 'cr', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(4, 1, '刻晴', 'cr', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(5, 1, '七七', 'cr', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(6, 1, '天空之翼', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(7, 1, '天空之卷', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(8, 1, '天空之脊', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(9, 1, '天空之傲', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(10, 1, '天空之刃', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(11, 1, '風鷹劍', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(12, 1, '阿莫斯之弓', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(13, 1, '四風原典', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(14, 1, '和璞鳶', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18'),
(15, 1, '狼的末路', 'wp', '2021-12-11 14:43:18', '2021-12-11 14:43:18');

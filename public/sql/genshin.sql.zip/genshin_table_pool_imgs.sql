
-- --------------------------------------------------------

--
-- 資料表結構 `pool_imgs`
--
-- 建立時間： 2021-12-22 11:15:57
-- 最後更新： 2021-12-22 11:15:57
--

DROP TABLE IF EXISTS `pool_imgs`;
CREATE TABLE IF NOT EXISTS `pool_imgs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `pool_id` int NOT NULL,
  `cr_main_img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `wp_main_img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cr_thum_on_img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cr_thum_off_img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `wp_thum_on_img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `wp_thum_off_img` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表新增資料前，先清除舊資料 `pool_imgs`
--

TRUNCATE TABLE `pool_imgs`;
--
-- 傾印資料表的資料 `pool_imgs`
--

INSERT INTO `pool_imgs` (`id`, `pool_id`, `cr_main_img`, `wp_main_img`, `cr_thum_on_img`, `cr_thum_off_img`, `wp_thum_on_img`, `wp_thum_off_img`, `created_at`, `updated_at`) VALUES
(1, 0, '/pictures/pool_main/常駐池.png', '/pictures/pool_main/常駐池.png', '/pictures/pool_thum/常駐池_on.png', '/pictures/pool_thum/常駐池_off.png', '/pictures/pool_thum/常駐池_on.png', '/pictures/pool_thum/常駐池_off.png', '2021-12-11 16:42:36', '2021-12-11 16:42:36'),
(2, 1, '/pictures/pool_main/溫迪池.jfif', '/pictures/pool_main/溫迪武器池.jfif', '/pictures/pool_thum/溫迪池_on.png', '/pictures/pool_thum/溫迪池_off.png', '/pictures/pool_thum/溫迪武器池_on.png', '/pictures/pool_thum/溫迪武器池_off.png', '2021-12-11 16:51:03', '2021-12-11 16:51:03'),
(3, 2, '/pictures/pool_main/可莉池.jfif', '/pictures/pool_main/可莉武器池.jfif', '/pictures/pool_thum/可莉池_on.png', '/pictures/pool_thum/可莉池_off.png', '/pictures/pool_thum/可莉武器池_on.png', '/pictures/pool_thum/可莉武器池_off.png', '2021-12-11 16:51:03', '2021-12-11 16:51:03'),
(4, 3, '/pictures/pool_main/達達利亞池.jfif', '/pictures/pool_main/達達利亞武器池.jfif', '/pictures/pool_thum/達達利亞池_on.png', '/pictures/pool_thum/達達利亞池_off.png', '/pictures/pool_thum/達達利亞武器池_on.png', '/pictures/pool_thum/達達利亞武器池_off.png', '2021-12-11 16:51:03', '2021-12-11 16:51:03'),
(5, 4, '/pictures/pool_main/鍾離池.jfif', '/pictures/pool_main/鍾離武器池.jfif', '/pictures/pool_thum/鍾離池_on.png', '/pictures/pool_thum/鍾離池_off.png', '/pictures/pool_thum/鍾離武器池_on.png', '/pictures/pool_thum/鍾離武器池_off.png', '2021-12-11 16:51:03', '2021-12-11 16:51:03'),
(6, 5, '/pictures/pool_main/阿貝多池.jfif', '/pictures/pool_main/阿貝多武器池.jfif', '/pictures/pool_thum/阿貝多池_on.png', '/pictures/pool_thum/阿貝多池_off.png', '/pictures/pool_thum/阿貝多武器池_on.png', '/pictures/pool_thum/阿貝多武器池_off.png', '2021-12-11 16:51:03', '2021-12-11 16:51:03'),
(7, 6, '/pictures/pool_main/甘雨池.jfif', '/pictures/pool_main/甘雨武器池.jfif', '/pictures/pool_thum/甘雨池_on.png', '/pictures/pool_thum/甘雨池_off.png', '/pictures/pool_thum/甘雨武器池_on.png', '/pictures/pool_thum/甘雨武器池_off.png', '2021-12-11 16:51:03', '2021-12-11 16:51:03'),
(8, 7, '/pictures/pool_main/魈池.jfif', '/pictures/pool_main/魈武器池.jfif', '/pictures/pool_thum/魈池_on.png', '/pictures/pool_thum/魈池_off.png', '/pictures/pool_thum/魈武器池_on.png', '/pictures/pool_thum/魈武器池_off.png', '2021-12-11 17:02:23', '2021-12-11 17:02:23'),
(9, 8, '/pictures/pool_main/刻晴池.jfif', '/pictures/pool_main/刻晴武器池.jfif', '/pictures/pool_thum/刻晴池_on.png', '/pictures/pool_thum/刻晴池_off.png', '/pictures/pool_thum/刻晴武器池_on.png', '/pictures/pool_thum/刻晴武器池_off.png', '2021-12-11 17:05:45', '2021-12-11 17:05:45'),
(10, 9, '/pictures/pool_main/胡桃池.jfif', '/pictures/pool_main/胡桃武器池.jfif', '/pictures/pool_thum/胡桃池_on.png', '/pictures/pool_thum/胡桃池_off.png', '/pictures/pool_thum/胡桃武器池_on.png', '/pictures/pool_thum/胡桃武器池_off.png', '2021-12-11 17:07:51', '2021-12-11 17:07:51'),
(11, 10, '/pictures/pool_main/溫迪池2.jfif', '/pictures/pool_main/溫迪武器池2.jfif', '/pictures/pool_thum/溫迪池_on.png', '/pictures/pool_thum/溫迪池_off.png', '/pictures/pool_thum/溫迪武器池2_on.png', '/pictures/pool_thum/溫迪武器池2_off.png', '2021-12-11 17:09:24', '2021-12-11 17:09:24'),
(12, 11, '/pictures/pool_main/達達利亞池2.jfif', '/pictures/pool_main/達達利亞武器池2.jfif', '/pictures/pool_thum/達達利亞池_on.png', '/pictures/pool_thum/達達利亞池_off.png', '/pictures/pool_thum/達達利亞武器池2_on.png', '/pictures/pool_thum/達達利亞武器池2_off.png', '2021-12-11 17:32:28', '2021-12-11 17:32:28'),
(13, 12, '/pictures/pool_main/鍾離池2.jfif', '/pictures/pool_main/鍾離武器池2.jfif', '/pictures/pool_thum/鍾離池_on.png', '/pictures/pool_thum/鍾離池_off.png', '/pictures/pool_thum/鍾離武器池2_on.png', '/pictures/pool_thum/鍾離武器池2_off.png', '2021-12-11 17:34:47', '2021-12-11 17:34:47'),
(14, 13, '/pictures/pool_main/優菈池.jfif', '/pictures/pool_main/優菈武器池.jfif', '/pictures/pool_thum/優菈池_on.png', '/pictures/pool_thum/優菈池_off.png', '/pictures/pool_thum/優菈武器池_on.png', '/pictures/pool_thum/優菈武器池_off.png', '2021-12-11 17:38:00', '2021-12-11 17:38:00'),
(15, 14, '/pictures/pool_main/可莉池2.jfif', '/pictures/pool_main/可莉武器池2.jfif', '/pictures/pool_thum/可莉池_on.png', '/pictures/pool_thum/可莉池_off.png', '/pictures/pool_thum/可莉武器池2_on.png', '/pictures/pool_thum/可莉武器池2_off.png', '2021-12-11 17:39:29', '2021-12-11 17:39:29'),
(16, 15, '/pictures/pool_main/楓原萬葉池.jfif', '/pictures/pool_main/楓原萬葉武器池.jfif', '/pictures/pool_thum/楓原萬葉池_on.png', '/pictures/pool_thum/楓原萬葉池_off.png', '/pictures/pool_thum/楓原萬葉武器池_on.png', '/pictures/pool_thum/楓原萬葉武器池_off.png', '2021-12-11 17:40:50', '2021-12-11 17:40:50'),
(17, 16, '/pictures/pool_main/神里綾華池.jpg', '/pictures/pool_main/神里綾華武器池.jpg', '/pictures/pool_thum/神里綾華池_on.png', '/pictures/pool_thum/神里綾華池_off.png', '/pictures/pool_thum/神里綾華武器池_on.png', '/pictures/pool_thum/神里綾華武器池_off.png', '2021-12-11 17:42:03', '2021-12-11 17:42:03'),
(18, 17, '/pictures/pool_main/宵宮池.jpg', '/pictures/pool_main/宵宮武器池.jpg', '/pictures/pool_thum/宵宮池_on.png', '/pictures/pool_thum/宵宮池_off.png', '/pictures/pool_thum/宵宮武器池_on.png', '/pictures/pool_thum/宵宮武器池_off.png', '2021-12-11 17:43:14', '2021-12-11 17:43:14'),
(19, 18, '/pictures/pool_main/雷電將軍池.jpg', '/pictures/pool_main/雷電將軍武器池.jpg', '/pictures/pool_thum/雷電將軍池_on.png', '/pictures/pool_thum/雷電將軍池_off.png', '/pictures/pool_thum/雷電將軍武器池_on.png', '/pictures/pool_thum/雷電將軍武器池_off.png', '2021-12-11 17:44:37', '2021-12-11 17:44:37'),
(20, 19, '/pictures/pool_main/珊瑚宮心海池.jpg', '/pictures/pool_main/珊瑚宮心海武器池.jpg', '/pictures/pool_thum/珊瑚宮心海池_on.png', '/pictures/pool_thum/珊瑚宮心海池_off.png', '/pictures/pool_thum/珊瑚宮心海武器池_on.png', '/pictures/pool_thum/珊瑚宮心海武器池_off.png', '2021-12-11 17:46:13', '2021-12-11 17:46:13'),
(21, 20, '/pictures/pool_main/達達利亞池3.jfif', '/pictures/pool_main/達達利亞武器池3.jfif', '/pictures/pool_thum/達達利亞池_on.png', '/pictures/pool_thum/達達利亞池_off.png', '/pictures/pool_thum/達達利亞武器池3_on.png', '/pictures/pool_thum/達達利亞武器池3_off.png', '2021-12-11 17:47:27', '2021-12-11 17:47:27'),
(22, 21, '/pictures/pool_main/胡桃池2.jfif', '/pictures/pool_main/胡桃武器池2.jfif', '/pictures/pool_thum/胡桃池_on.png', '/pictures/pool_thum/胡桃池_off.png', '/pictures/pool_thum/胡桃武器池2_on.png', '/pictures/pool_thum/胡桃武器池2_off.png', '2021-12-11 17:48:58', '2021-12-11 17:48:58');

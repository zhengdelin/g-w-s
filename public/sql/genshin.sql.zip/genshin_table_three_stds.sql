
-- --------------------------------------------------------

--
-- 資料表結構 `three_stds`
--
-- 建立時間： 2021-12-22 11:16:32
-- 最後更新： 2021-12-22 11:16:32
--

DROP TABLE IF EXISTS `three_stds`;
CREATE TABLE IF NOT EXISTS `three_stds` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表新增資料前，先清除舊資料 `three_stds`
--

TRUNCATE TABLE `three_stds`;
--
-- 傾印資料表的資料 `three_stds`
--

INSERT INTO `three_stds` (`id`, `name`, `kind`, `created_at`, `updated_at`) VALUES
(1, '以理服人', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(2, '冷刃', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(3, '沐浴龍血的劍', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(4, '飛天御劍', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(5, '神射手之誓', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(6, '討龍英傑譚', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(7, '黑纓槍', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(8, '翡玉法球', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(9, '彈弓', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(10, '黎明神劍', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(11, '鐵影闊劍', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25'),
(12, '魔導緒論', 'wp', '2021-12-12 17:44:25', '2021-12-12 17:44:25');
